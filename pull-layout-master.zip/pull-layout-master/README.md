pull-layout
===========

android pull-layout,include 'pull to zoom header' etc.

###zoom-layout
![zoom-layout](https://raw.github.com/kai-wang-john/pull-layout/master/screenshot/zoom-layout.gif)

----------------

###zoom-list
![zoom-list](https://raw.github.com/kai-wang-john/pull-layout/master/screenshot/zoom-list.gif)

-------------
