Change Log
==========

## Version 1.0.2

_2016-07-13_

 *  Fix: Incorrect drawing when padding is set.

## Version 1.0.0

_2016-07-07_

 *  Initial release.