Change Log
==========

Version 1.0.2 (2015-04-30)
----------------------------

- Fix `OnLongClickListener` will not trigger `OnClickListener` if event is consumed

Version 1.0.1 (2015-02-16)
----------------------------

- Prefix all `MaterialRippleLayout` attributes with `mrl_` to remove possible ambiguity when using with other libraries.


Version 1.0.0 (2015-02-01)
----------------------------

Initial release.